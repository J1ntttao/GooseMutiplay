# Goose Online

Steam-only two-player online co-op mod for the Unity Mono Steam build of Untitled Goose Game.

## 给朋友的安装方式

1. 把整个 `GooseOnline-0.4.19.zip` 传给朋友。
2. 朋友解压 ZIP，不要直接在压缩包里运行。
3. 双击 `Install-GooseOnline.bat`。
4. 如果 Windows 弹出管理员权限窗口，选择“是”。
5. 安装结束后从 Steam 启动游戏，进游戏按 `F8`。

安装器会自动寻找 Steam 库；找不到时会提示粘贴游戏目录。ZIP 已内置 BepInEx，不需要朋友另外下载 mod loader。

## 卸载方式

在同一个解压目录双击 `Uninstall-GooseOnline.bat`。它只移除 Goose Online 插件和安装标记，会保留 BepInEx，避免影响朋友安装的其他 mod。

## 联机使用

1. 两名玩家都完成安装，并使用相同游戏版本和 mod 版本。
2. 房主进游戏按 `F8`，点击“创建 Steam 房间”。
3. 点击“打开 Steam 邀请面板”，邀请朋友。
4. 朋友接受 Steam 邀请后等待握手完成。

当前版本固定两名玩家、Steam-only、不支持主机迁移。每台电脑使用本机第一控制槽操作自己的鹅，因此键盘、手柄或兼容的键鼠组合都可以使用。插件加载日志位于游戏目录的 `BepInEx\LogOutput.log`。

0.4.19 会按 P1/P2 身份映射远端鹅，并在联机后自动激活 P2；鹅的移动和动作使用独立低延迟姿态同步，实时世界快照不会被初始进度同步失败阻断，超大世界和进度包会在协议上限内自动裁剪并优先保留开关、任务和 NPC，持有或刚放下的物品不会被旧快照覆盖，水龙头等开关、NPC 位置和 NPC 携带物品也会随可靠世界快照同步，并支持动态物体路径回退匹配。插件绕过原版不稳定的批量双人鹅激活函数，避免单人初始化数组越界。链接成功后，双方都要手动进入单人游戏中，再由房主一次性同步已完成任务、门/开关、区域、存档进度和两只鹅的初始位置。游戏启动时会从 GitHub 检查并下载最新 `GooseOnline.dll`，不会替换 BepInEx；下载期间请勿关闭游戏，下载完成后退出游戏，更新器会替换 DLL，随后手动重启。按 `F8` 可以显示或隐藏插件面板。两台电脑都要安装 0.4.19，更新后请完全退出并重新启动游戏。

## 开发者构建

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\build.ps1
powershell -ExecutionPolicy Bypass -File .\scripts\package.ps1
```
